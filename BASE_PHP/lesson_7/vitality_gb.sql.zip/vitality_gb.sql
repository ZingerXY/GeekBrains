-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Фев 17 2022 г., 02:49
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `vitality_gb`
--

-- --------------------------------------------------------

--
-- Структура таблицы `customers`
--
-- Создание: Фев 14 2022 г., 22:17
-- Последнее обновление: Фев 16 2022 г., 23:46
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `phone_number` varchar(30) NOT NULL,
  `address` varchar(120) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `customers`
--

INSERT INTO `customers` (`id`, `full_name`, `phone_number`, `address`, `user_id`) VALUES
(1, 'Алеша', '112', 'Пушкина', 1),
(7, 'Иван', '812', 'Алтай', 7),
(8, 'Костя', '912', 'КНР', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--
-- Создание: Фев 01 2022 г., 16:51
-- Последнее обновление: Фев 16 2022 г., 14:37
--

DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(60) NOT NULL,
  `description` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `price`, `image`, `description`) VALUES
(4, 'Помидорочка', 25, '5-May-and-tomato-0141-1024x739.jpg', 'Красная помидорка, скушай меня скорей'),
(5, 'Книга', 100, '9785817402209-us.jpg', 'Очень полезная книга'),
(6, 'Уточка', 33, 'Duck.png', 'Обычная желтая утка для ванны');

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--
-- Создание: Янв 17 2022 г., 15:29
-- Последнее обновление: Фев 16 2022 г., 14:48
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `filename` varchar(60) NOT NULL,
  `title` varchar(60) NOT NULL,
  `alt` varchar(120) NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`id`, `filename`, `title`, `alt`, `views`) VALUES
(2, 'normal_06404.jpg', 'Котик', 'Котик', 6),
(4, '1335868138_malenkie_kotjata_43.jpg', 'Котенок', 'Маленький котенок', 6),
(5, '062.jpg', 'Смешной котенок', 'Смешной котенок', 10),
(6, 'Kotiki_7.jpg', 'Зевающий кот', 'Зевающий кот', 8);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--
-- Создание: Фев 14 2022 г., 23:24
-- Последнее обновление: Фев 16 2022 г., 23:47
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1',
  `total_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `date`, `status`, `total_price`) VALUES
(14, 1, '2022-02-17 02:23:16', 1, 240),
(16, 7, '2022-02-17 02:41:51', 1, 132),
(17, 1, '2022-02-17 02:45:56', 3, 482),
(18, 8, '2022-02-17 02:46:29', 2, 183);

-- --------------------------------------------------------

--
-- Структура таблицы `order_items`
--
-- Создание: Фев 14 2022 г., 23:34
-- Последнее обновление: Фев 16 2022 г., 23:46
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `name`, `price`, `count`, `goods_id`) VALUES
(24, 14, 'Помидорочка', 25, 3, 4),
(25, 14, 'Уточка', 33, 5, 6),
(32, 16, 'Уточка', 33, 4, 6),
(33, 17, 'Уточка', 33, 4, 6),
(34, 17, 'Книга', 100, 3, 5),
(35, 17, 'Помидорочка', 25, 2, 4),
(36, 18, 'Книга', 100, 1, 5),
(37, 18, 'Помидорочка', 25, 2, 4),
(38, 18, 'Уточка', 33, 1, 6);

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--
-- Создание: Фев 16 2022 г., 16:36
-- Последнее обновление: Фев 16 2022 г., 21:51
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `review` varchar(300) NOT NULL,
  `public` tinyint(1) DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `name`, `review`, `public`, `date`) VALUES
(2, 'Вадим', 'Магаз просто невероятный! \r\nНе встречал ничего лучше.', 1, '2022-01-24 14:25:16'),
(3, 'Константин', 'Это лучший магазин который я видел в своей жизни!', 1, '2022-01-24 14:25:43'),
(4, 'Григорий', 'Это просто потрясающе! \r\nТут есть все нужные мне товары!', 1, '2022-01-24 14:26:21'),
(6, 'admin', 'Благодарю Вас за Ваши замечательные отзывы)', 1, '2022-02-16 14:31:33'),
(8, 'Фома', 'Только на этом сайте я смог найти нужный мне товар!', 1, '2022-02-16 16:34:29');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Фев 09 2022 г., 21:22
-- Последнее обновление: Фев 16 2022 г., 15:36
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `level`) VALUES
(1, 'admin', '$2y$11$ceb20772e0c9d240c75ebuKlOvRyOwwWlNXZGLoy1CKGXDG0pZ1zu', 100),
(7, 'tester', '$2y$10$aAR/Y7PtPKGMTMVUrp3OoepC.kwWelIVwpCLZzCNMc2G4ef9K/CL2', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
